
import React from 'react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  user: { username: string; role: 'master' | 'staff' };
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, user, onLogout }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Monitoramento', icon: '⚡', role: 'master' },
    { id: 'create-log', label: 'Novo Registro', icon: '📝', role: 'any' },
    { id: 'live-logs', label: 'Arquivo de Logs', icon: '📚', role: 'any' },
    { id: 'manage-team', label: 'Administração', icon: '🛡️', role: 'master' },
    { id: 'ai-analyst', label: 'Analista de IA', icon: '🧠', role: 'master' },
  ];

  const filteredItems = menuItems.filter(item => 
    item.role === 'any' || (item.role === 'master' && user.role === 'master')
  );

  return (
    <div className="w-72 bg-[#0a0d14] h-screen border-r border-white/5 flex flex-col shrink-0 z-20">
      <div className="p-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-amber-500 to-orange-600 rounded-xl flex items-center justify-center text-white font-black text-xl shadow-lg shadow-orange-500/20">
            I
          </div>
          <div>
            <h1 className="text-lg font-extrabold text-white tracking-tight leading-none">IMPERIO</h1>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Gestão de RP</p>
          </div>
        </div>
      </div>
      
      <nav className="flex-1 px-6 space-y-1">
        {filteredItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full flex items-center space-x-4 px-5 py-4 rounded-xl transition-all duration-300 group ${
              activeTab === item.id 
                ? 'bg-white/5 text-white' 
                : 'text-slate-500 hover:text-slate-300 hover:bg-white/[0.02]'
            }`}
          >
            <span className={`text-lg transition-transform group-hover:scale-110 ${activeTab === item.id ? 'opacity-100' : 'opacity-50'}`}>
              {item.icon}
            </span>
            <span className="font-semibold text-sm tracking-tight">{item.label}</span>
            {activeTab === item.id && <div className="ml-auto w-1 h-1 rounded-full bg-orange-500 shadow-[0_0_8px_#f97316]"></div>}
          </button>
        ))}
      </nav>

      <div className="p-8 mt-auto">
        <div className="bg-white/[0.03] p-5 rounded-2xl border border-white/5 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-[10px] font-bold text-slate-400 border border-white/10 uppercase">
              {user.username[0]}
            </div>
            <div className="overflow-hidden">
              <p className="text-xs font-bold text-slate-200 truncate">{user.username}</p>
              <p className="text-[9px] text-slate-500 uppercase font-black tracking-tighter mt-0.5">Acesso {user.role}</p>
            </div>
          </div>
        </div>
        
        <button 
          onClick={onLogout}
          className="w-full py-3 rounded-xl text-slate-500 hover:text-rose-400 hover:bg-rose-400/5 transition-all text-xs font-bold flex items-center justify-center gap-2"
        >
          Sair do Sistema
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
