
import React, { useState, useEffect } from 'react';
import { analyzeLogsForAnomalies } from '../services/geminiService';
import { LogEntry } from '../types';

interface AIAnalystProps {
  logs: LogEntry[];
}

const AIAnalyst: React.FC<AIAnalystProps> = ({ logs }) => {
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState('');

  const loadingMessages = [
    "Sincronizando banco de dados...",
    "Varrendo registros de combate...",
    "Analisando métricas econômicas...",
    "Cruzando dados de usuários...",
    "Gerando diagnóstico estratégico..."
  ];

  useEffect(() => {
    let interval: any;
    if (loading) {
      interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) return 100;
          const next = prev + (Math.random() * 5);
          const msgIndex = Math.floor((next / 100) * loadingMessages.length);
          if (msgIndex < loadingMessages.length) setStatusText(loadingMessages[msgIndex]);
          return next;
        });
      }, 300);
    } else {
      setProgress(0);
      if (interval) clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [loading]);

  const handleRunAnalysis = async () => {
    setLoading(true);
    setAnalysis(null);
    try {
      const result = await analyzeLogsForAnomalies(logs);
      setProgress(100);
      setTimeout(() => {
        setAnalysis(result);
        setLoading(false);
      }, 400);
    } catch (e) {
      setAnalysis("Falha na comunicação com o núcleo da IA.");
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12">
      <div className="bg-[#0f121a] border border-white/5 p-12 rounded-[3rem] shadow-2xl relative overflow-hidden group">
        <div className="absolute -top-24 -right-24 w-64 h-64 bg-orange-600/10 rounded-full blur-[80px] group-hover:bg-orange-600/15 transition-all duration-1000"></div>
        
        <div className="relative z-10 text-center space-y-6">
          <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center mx-auto border border-white/10 shadow-inner">
            <span className="text-3xl">🧠</span>
          </div>
          
          <div className="space-y-2">
            <h2 className="text-3xl font-extrabold text-white tracking-tight">Analista de Inteligência</h2>
            <p className="text-slate-500 text-sm max-w-lg mx-auto leading-relaxed">
              O núcleo de processamento examina comportamentos anômalos e infrações regimentais com precisão algorítmica.
            </p>
          </div>

          <div className="pt-6">
            {!loading ? (
              <div className="flex items-center justify-center gap-4">
                <button
                  onClick={handleRunAnalysis}
                  className="px-10 py-4 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-2xl transition-all shadow-lg shadow-orange-600/20 active:scale-95"
                >
                  Executar Varredura
                </button>
                {analysis && (
                  <button onClick={() => setAnalysis(null)} className="text-slate-500 hover:text-slate-300 text-xs font-bold uppercase tracking-widest">Limpar</button>
                )}
              </div>
            ) : (
              <div className="max-w-sm mx-auto space-y-6 animate-in fade-in zoom-in-95">
                <div className="flex justify-between items-end">
                  <span className="text-xs font-bold text-orange-500/80 uppercase tracking-widest animate-pulse">{statusText}</span>
                  <span className="text-white mono text-xs">{Math.floor(progress)}%</span>
                </div>
                <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden border border-white/5">
                  <div 
                    className="h-full bg-gradient-to-r from-orange-600 to-amber-400 transition-all duration-300 shadow-[0_0_10px_rgba(249,115,22,0.3)]"
                    style={{ width: `${progress}%` }}
                  ></div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {analysis && !loading && (
        <div className="bg-white/[0.02] border border-white/5 p-10 rounded-[3rem] backdrop-blur-xl animate-in fade-in slide-in-from-bottom-8 duration-700">
          <div className="flex items-center gap-3 mb-8 border-b border-white/5 pb-8">
            <div className="w-1 h-5 bg-orange-500 rounded-full"></div>
            <h3 className="text-slate-200 font-bold text-sm tracking-tight">Relatório de Segurança</h3>
            <span className="ml-auto text-[10px] text-slate-500 font-mono italic">Gerado via Gemini Protocol</span>
          </div>
          <div className="text-slate-300 text-[14px] leading-relaxed font-medium font-mono whitespace-pre-wrap selection:bg-orange-500/20">
            {analysis}
          </div>
        </div>
      )}
    </div>
  );
};

export default AIAnalyst;
