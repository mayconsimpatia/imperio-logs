
import React, { useState } from 'react';
import { LogCategory, LogEntry } from '../types';

interface LogCreatorProps {
  onLogCreated: (log: LogEntry) => void;
}

const LogCreator: React.FC<LogCreatorProps> = ({ onLogCreated }) => {
  const [formData, setFormData] = useState({
    playerNick: '',
    playerId: '',
    punishTime: '',
    punishDate: new Date().toISOString().split('T')[0],
    adminName: 'Staff Imperador',
    category: LogCategory.ADMIN,
    action: 'BAN_PLAYER',
    reason: '',
  });

  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    let details = '';
    if (formData.action === 'BAN_PLAYER') {
      details = `[STAFF] ${formData.adminName} baniu [ID: ${formData.playerId}] | MOTIVO: ${formData.reason} | TIPO: ${formData.punishTime}`;
    } else if (formData.action === 'ARREST_PLAYER') {
      details = `[OFICIAL] ${formData.adminName} prendeu [ID: ${formData.playerId}] | MOTIVO: ${formData.reason} | PENA: ${formData.punishTime}`;
    } else {
      details = `[STAFF] ${formData.adminName} kickou [ID: ${formData.playerId}] | MOTIVO: ${formData.reason}`;
    }

    const newLog: LogEntry = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date(formData.punishDate + 'T' + new Date().toTimeString().split(' ')[0]).toISOString(),
      category: formData.category,
      player: { 
        id: formData.playerId, 
        name: formData.playerNick 
      },
      action: formData.action,
      details: details,
      severity: formData.action === 'BAN_PLAYER' ? 'critical' : formData.action === 'ARREST_PLAYER' ? 'high' : 'medium'
    };

    onLogCreated(newLog);
    setSuccess(true);
    setTimeout(() => setSuccess(false), 3000);
    
    // Limpar campos básicos, manter admin
    setFormData(prev => ({
      ...prev,
      playerNick: '',
      playerId: '',
      punishTime: '',
      reason: ''
    }));
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-[#1e293b]/50 border border-slate-800 rounded-2xl p-8 backdrop-blur-md shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-6 opacity-5 pointer-events-none text-6xl">📜</div>
        
        <div className="mb-8">
          <h3 className="text-xl font-bold text-white flex items-center">
            <span className="w-1.5 h-5 bg-yellow-500 rounded-full mr-3"></span>
            Formalizar Sentença Imperial
          </h3>
          <p className="text-sm text-slate-400 mt-1">O registro será auditado pela IA e armazenado permanentemente.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Nick do Player</label>
              <input 
                required
                type="text" 
                value={formData.playerNick}
                onChange={e => setFormData({...formData, playerNick: e.target.value})}
                placeholder="Ex: John_Doe"
                className="w-full bg-slate-900/80 border border-slate-700 rounded-xl px-4 py-3 text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500/50 transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">ID do Player</label>
              <input 
                required
                type="text" 
                value={formData.playerId}
                onChange={e => setFormData({...formData, playerId: e.target.value})}
                placeholder="Ex: 501"
                className="w-full bg-slate-900/80 border border-slate-700 rounded-xl px-4 py-3 text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500/50 transition-all"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Ação Punitiva</label>
              <select 
                value={formData.action}
                onChange={e => {
                  const val = e.target.value;
                  const cat = val === 'ARREST_PLAYER' ? LogCategory.POLICE : LogCategory.ADMIN;
                  setFormData({...formData, action: val, category: cat});
                }}
                className="w-full bg-slate-900/80 border border-slate-700 rounded-xl px-4 py-3 text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500/50 transition-all"
              >
                <option value="BAN_PLAYER">Banimento</option>
                <option value="ARREST_PLAYER">Prisão (Oficial)</option>
                <option value="KICK_PLAYER">Chute (Kick)</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Tempo / Duração</label>
              <input 
                required
                type="text" 
                value={formData.punishTime}
                onChange={e => setFormData({...formData, punishTime: e.target.value})}
                placeholder="Ex: Permanente, 30 dias, 60 meses"
                className="w-full bg-slate-900/80 border border-slate-700 rounded-xl px-4 py-3 text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500/50 transition-all"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Data do Ocorrido</label>
              <input 
                type="date" 
                value={formData.punishDate}
                onChange={e => setFormData({...formData, punishDate: e.target.value})}
                className="w-full bg-slate-900/80 border border-slate-700 rounded-xl px-4 py-3 text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500/50 transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Admin Responsável</label>
              <input 
                readOnly
                type="text" 
                value={formData.adminName}
                className="w-full bg-slate-800/50 border border-slate-700 rounded-xl px-4 py-3 text-sm text-slate-500 cursor-not-allowed"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Motivo Detalhado</label>
            <textarea 
              required
              rows={3}
              value={formData.reason}
              onChange={e => setFormData({...formData, reason: e.target.value})}
              placeholder="Descreva detalhadamente o que o jogador fez..."
              className="w-full bg-slate-900/80 border border-slate-700 rounded-xl px-4 py-3 text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500/50 transition-all resize-none"
            />
          </div>

          <button 
            type="submit"
            className="w-full bg-gradient-to-r from-orange-600 to-yellow-600 hover:from-orange-500 hover:to-yellow-500 text-white font-bold py-4 rounded-xl shadow-lg shadow-orange-900/20 transform transition-all active:scale-[0.98]"
          >
            EMITIR SENTENÇA IMPERIAL
          </button>
        </form>

        {success && (
          <div className="mt-6 p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-center text-emerald-400 text-sm animate-in fade-in slide-in-from-top-2">
            <span className="mr-3">✅</span>
            Ocorrência registrada e vinculada aos logs da cidade com sucesso.
          </div>
        )}
      </div>
    </div>
  );
};

export default LogCreator;
