
import React from 'react';
import { LogEntry, LogCategory } from '../types';
import { CATEGORY_COLORS, SEVERITY_COLORS } from '../constants';

interface LogTableProps {
  logs: LogEntry[];
  title?: string;
  onDelete?: (id: string) => void;
}

const LogTable: React.FC<LogTableProps> = ({ logs, title, onDelete }) => {
  return (
    <div className="bg-[#1e293b]/50 border border-slate-800 rounded-xl overflow-hidden backdrop-blur-sm">
      {title && (
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/30">
          <h3 className="font-bold text-slate-200 flex items-center">
            <span className="w-1.5 h-4 bg-orange-500 rounded-full mr-3"></span>
            {title}
          </h3>
          <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{logs.length} ocorrências</span>
        </div>
      )}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="bg-slate-900/80 border-b border-slate-800">
              <th className="px-6 py-4 font-bold text-slate-400 uppercase text-[10px] tracking-wider">Data/Hora</th>
              <th className="px-6 py-4 font-bold text-slate-400 uppercase text-[10px] tracking-wider">Categoria</th>
              <th className="px-6 py-4 font-bold text-slate-400 uppercase text-[10px] tracking-wider">Responsável</th>
              <th className="px-6 py-4 font-bold text-slate-400 uppercase text-[10px] tracking-wider">Ação</th>
              <th className="px-6 py-4 font-bold text-slate-400 uppercase text-[10px] tracking-wider">Detalhes Estruturados</th>
              <th className="px-6 py-4 font-bold text-slate-400 uppercase text-[10px] tracking-wider">Status</th>
              {onDelete && <th className="px-6 py-4 font-bold text-slate-400 uppercase text-[10px] tracking-wider text-right">Comandos</th>}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/50">
            {logs.map((log) => (
              <tr key={log.id} className="hover:bg-orange-500/5 transition-colors group border-l-2 border-l-transparent hover:border-l-orange-500">
                <td className="px-6 py-4 whitespace-nowrap mono text-[11px] text-slate-500">
                  {new Date(log.timestamp).toLocaleString('pt-BR', { 
                    day: '2-digit', 
                    month: '2-digit',
                    hour: '2-digit', 
                    minute: '2-digit', 
                    second: '2-digit' 
                  })}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase border ${CATEGORY_COLORS[log.category]}`}>
                    {log.category}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex flex-col">
                    <span className="text-slate-200 font-semibold text-xs">{log.player.name}</span>
                    <span className="text-[10px] text-slate-500 font-mono">ID: {log.player.id}</span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="mono text-[10px] font-bold text-orange-400/80">{log.action}</span>
                </td>
                <td className="px-6 py-4 min-w-[300px]">
                  <p className="text-slate-300 text-xs font-medium leading-relaxed">
                    {log.details.split('|').map((part, i) => (
                      <span key={i} className={i > 0 ? "border-l border-slate-700 ml-2 pl-2" : ""}>
                        {part.trim()}
                      </span>
                    ))}
                  </p>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                   <span className={`text-[10px] font-black uppercase tracking-tighter ${SEVERITY_COLORS[log.severity]}`}>
                    {log.severity}
                   </span>
                </td>
                {onDelete && (
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <button 
                      onClick={() => {
                        if(confirm('Deseja realmente apagar este registro do banco de dados?')) {
                          onDelete(log.id);
                        }
                      }}
                      className="p-2 bg-red-500/10 text-red-500 rounded-lg hover:bg-red-500 hover:text-white transition-all transform hover:scale-110"
                      title="Excluir Registro"
                    >
                      🗑️
                    </button>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {logs.length === 0 && (
        <div className="p-20 text-center">
          <p className="text-slate-500 font-bold uppercase tracking-widest text-xs">Nenhum registro encontrado para os filtros aplicados.</p>
        </div>
      )}
    </div>
  );
};

export default LogTable;
