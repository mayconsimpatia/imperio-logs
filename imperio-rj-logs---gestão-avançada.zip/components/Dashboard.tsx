
import React, { useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { LogEntry, LogCategory } from '../types';
import { CATEGORY_COLORS } from '../constants';

interface DashboardProps {
  logs: LogEntry[];
}

const Dashboard: React.FC<DashboardProps> = ({ logs }) => {
  // Cálculos em tempo real baseados nos logs
  const stats = useMemo(() => {
    return [
      { 
        label: 'Total de Registros', 
        value: logs.length, 
        icon: '⚡', 
        color: 'text-blue-400',
        borderColor: 'group-hover:border-blue-500/30'
      },
      { 
        label: 'Ações Policiais', 
        value: logs.filter(l => l.category === LogCategory.POLICE).length, 
        icon: '👮', 
        color: 'text-emerald-400',
        borderColor: 'group-hover:border-emerald-500/30'
      },
      { 
        label: 'Banimentos', 
        value: logs.filter(l => l.action === 'BAN_PLAYER').length, 
        icon: '🚫', 
        color: 'text-rose-400',
        borderColor: 'group-hover:border-rose-500/30'
      },
      { 
        label: 'Mov. Econômica', 
        value: logs.filter(l => l.category === LogCategory.ECONOMY).length, 
        icon: '💰', 
        color: 'text-amber-400',
        borderColor: 'group-hover:border-amber-500/30'
      },
    ];
  }, [logs]);

  // Dados para o Gráfico de Área (Atividade por hora - Simulado baseado nos dados existentes)
  const activityData = useMemo(() => {
    // Agrupa logs por hora (simplificado para demonstração)
    const data = logs.reduce((acc: any, log) => {
      const hour = new Date(log.timestamp).getHours();
      const key = `${hour}h`;
      acc[key] = (acc[key] || 0) + 1;
      return acc;
    }, {});

    // Garante que mostramos pelo menos alguns horários
    const chartData = [
      { time: '00h', actions: data['0h'] || 0 },
      { time: '06h', actions: data['6h'] || 0 },
      { time: '12h', actions: data['12h'] || 2 }, // Mock leve para não ficar vazio
      { time: '18h', actions: data['18h'] || 5 },
      { time: '23h', actions: data['23h'] || 1 },
    ];
    return chartData;
  }, [logs]);

  // Dados para o Gráfico de Pizza (Distribuição por Categoria)
  const pieData = useMemo(() => {
    const counts: Record<string, number> = {};
    logs.forEach(log => {
      counts[log.category] = (counts[log.category] || 0) + 1;
    });

    const colors: Record<string, string> = {
      [LogCategory.ADMIN]: '#6366f1', // Indigo
      [LogCategory.POLICE]: '#10b981', // Emerald
      [LogCategory.COMBAT]: '#f43f5e', // Rose
      [LogCategory.ECONOMY]: '#f59e0b', // Amber
      [LogCategory.VEHICLE]: '#3b82f6', // Blue
      [LogCategory.GENERAL]: '#64748b', // Slate
    };

    return Object.keys(counts).map(cat => ({
      name: cat,
      value: counts[cat],
      color: colors[cat] || '#cbd5e1'
    }));
  }, [logs]);

  const recentLogs = logs.slice(0, 5);

  return (
    <div className="space-y-8 animate-in fade-in duration-1000 pb-10">
      {/* Cards de Estatísticas */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <div key={i} className={`bg-[#0f121a] border border-white/5 p-6 rounded-[2rem] group transition-all duration-500 ${stat.borderColor} hover:bg-white/[0.01]`}>
            <div className="flex justify-between items-start mb-4">
              <div className={`w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-xl shadow-inner ${stat.color}`}>
                {stat.icon}
              </div>
              <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest bg-slate-900 px-2 py-1 rounded-lg">24H</span>
            </div>
            <div>
              <h4 className="text-3xl font-extrabold text-white group-hover:scale-105 transition-transform origin-left">{stat.value}</h4>
              <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.1em] mt-1">{stat.label}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Gráfico Principal */}
        <div className="lg:col-span-2 bg-[#0f121a] border border-white/5 p-8 rounded-[2.5rem] min-h-[400px]">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-slate-200 font-bold text-sm tracking-tight flex items-center gap-3">
              <span className="w-2 h-2 bg-orange-500 rounded-full animate-pulse"></span>
              Fluxo de Atividade (Timeline)
            </h3>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={activityData}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f97316" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                <XAxis dataKey="time" stroke="#475569" fontSize={10} tickLine={false} axisLine={false} dy={10} />
                <YAxis stroke="#475569" fontSize={10} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #ffffff10', borderRadius: '12px', color: '#fff', fontSize: '12px' }}
                  cursor={{ stroke: '#ffffff10', strokeWidth: 2 }}
                />
                <Area type="monotone" dataKey="actions" stroke="#f97316" strokeWidth={3} fillOpacity={1} fill="url(#colorValue)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Gráfico de Pizza (Categorias) */}
        <div className="bg-[#0f121a] border border-white/5 p-8 rounded-[2.5rem] flex flex-col">
          <h3 className="text-slate-200 font-bold text-sm tracking-tight mb-4">Distribuição</h3>
          <div className="flex-1 min-h-[250px] relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                  stroke="none"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                   contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #ffffff10', borderRadius: '8px', fontSize: '12px' }}
                   itemStyle={{ color: '#fff' }}
                />
                <Legend 
                  verticalAlign="bottom" 
                  height={36}
                  iconSize={8}
                  wrapperStyle={{ fontSize: '10px', fontWeight: 'bold', textTransform: 'uppercase', opacity: 0.7 }}
                />
              </PieChart>
            </ResponsiveContainer>
            {/* Texto central do gráfico */}
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center pointer-events-none pb-8">
              <span className="block text-2xl font-black text-white">{logs.length}</span>
              <span className="block text-[8px] text-slate-500 uppercase font-bold tracking-widest">Logs</span>
            </div>
          </div>
        </div>
      </div>

      {/* Lista Rápida (Live Feed) */}
      <div className="bg-[#0f121a] border border-white/5 rounded-[2.5rem] overflow-hidden">
        <div className="p-8 border-b border-white/5 flex justify-between items-center">
          <h3 className="text-slate-200 font-bold text-sm tracking-tight">Últimos Registros (Live Feed)</h3>
          <span className="text-[9px] bg-emerald-500/10 text-emerald-400 px-3 py-1 rounded-full font-black uppercase tracking-widest animate-pulse">Online</span>
        </div>
        <div className="divide-y divide-white/5">
          {recentLogs.map((log) => (
            <div key={log.id} className="p-6 flex items-center justify-between hover:bg-white/[0.01] transition-colors group">
              <div className="flex items-center gap-4">
                 <div className={`w-2 h-12 rounded-full ${
                    log.severity === 'critical' ? 'bg-rose-500' : 
                    log.severity === 'high' ? 'bg-orange-500' : 'bg-slate-700'
                 }`}></div>
                 <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-white font-bold text-sm">{log.player.name}</span>
                      <span className="text-[10px] text-slate-500 font-mono bg-slate-900 px-1.5 rounded">ID: {log.player.id}</span>
                      <span className="text-[9px] text-slate-500 font-black uppercase tracking-widest ml-2 border border-slate-800 px-1 rounded">{log.category}</span>
                    </div>
                    <p className="text-slate-400 text-xs truncate max-w-md">{log.details.split('|')[0]}</p>
                 </div>
              </div>
              <div className="text-right hidden sm:block">
                 <span className="text-[10px] font-black uppercase text-slate-500 tracking-wider block">{log.action}</span>
                 <span className="text-[9px] text-slate-600 font-mono">
                    {new Date(log.timestamp).toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'})}
                 </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
