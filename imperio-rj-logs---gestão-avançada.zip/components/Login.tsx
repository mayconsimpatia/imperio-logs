
import React, { useState } from 'react';

interface LoginProps {
  onLogin: (user: { username: string; role: 'master' | 'staff' }) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!username || !password) {
      setError('Identificação e código são obrigatórios.');
      return;
    }

    // Acesso Master do Furious
    if (username.toLowerCase() === 'furious' && password === '11061958') {
      onLogin({ username: 'furious', role: 'master' });
    } else {
      // Outros entram como staff pendente (precisa de aprovação do furious)
      onLogin({ username: username, role: 'staff' });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0b0f1a] px-4 relative">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-orange-600/10 rounded-full blur-[100px]"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-yellow-600/5 rounded-full blur-[100px]"></div>
      </div>

      <div className="max-w-md w-full bg-slate-900/40 border border-slate-800 p-10 rounded-[2.5rem] backdrop-blur-2xl shadow-2xl relative z-10">
        <div className="text-center mb-10">
          <div className="inline-block px-3 py-1 bg-orange-500/10 border border-orange-500/20 rounded-full mb-4">
            <span className="text-[10px] text-orange-400 font-black uppercase tracking-widest">Acesso Administrativo</span>
          </div>
          <h1 className="text-4xl font-black text-white tracking-tighter mb-2">IMPERIO <span className="text-orange-500">RJ</span></h1>
          <p className="text-slate-500 text-xs font-bold uppercase tracking-[0.2em]">Terminal de Logs Staff</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-4">Usuário / Staff</label>
            <input 
              type="text" 
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-slate-950/50 border border-slate-800 rounded-2xl px-6 py-4 text-slate-200 focus:border-orange-500/50 outline-none transition-all placeholder:text-slate-700"
              placeholder="Digite seu nome..."
            />
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-4">Código Imperial</label>
            <input 
              type="password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-slate-950/50 border border-slate-800 rounded-2xl px-6 py-4 text-slate-200 focus:border-orange-500/50 outline-none transition-all placeholder:text-slate-700"
              placeholder="Sua senha staff..."
            />
          </div>

          {error && (
            <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-2xl animate-shake">
              <p className="text-red-400 text-[10px] font-black text-center uppercase tracking-widest leading-none">
                {error}
              </p>
            </div>
          )}

          <button 
            type="submit"
            className="w-full bg-orange-600 hover:bg-orange-500 text-white font-black py-5 rounded-2xl shadow-xl shadow-orange-950/50 transition-all active:scale-95 uppercase tracking-widest text-xs"
          >
            Acessar Sistema
          </button>
        </form>

        <div className="mt-8 pt-8 border-t border-slate-800/50 text-center">
          <p className="text-[9px] text-slate-600 font-bold uppercase tracking-widest">Protegido por Criptografia Imperial</p>
        </div>
      </div>
    </div>
  );
};

export default Login;
