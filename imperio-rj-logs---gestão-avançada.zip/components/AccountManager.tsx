
import React from 'react';
import { StaffAccount } from '../types';

interface AccountManagerProps {
  accounts: StaffAccount[];
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
  onDelete: (id: string) => void;
}

const AccountManager: React.FC<AccountManagerProps> = ({ accounts, onApprove, onReject, onDelete }) => {
  return (
    <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500">
      <div className="bg-orange-600/10 border border-orange-500/20 p-6 rounded-3xl flex items-center justify-between shadow-2xl shadow-orange-900/5">
        <div>
          <h2 className="text-xl font-black text-white uppercase tracking-tight">Gestão de Equipe Administrativa</h2>
          <p className="text-slate-500 text-xs font-medium">Apenas o Administrador <span className="text-orange-400">furious</span> pode aprovar novos acessos.</p>
        </div>
        <div className="flex gap-4">
          <div className="px-5 py-2 bg-slate-900/50 rounded-2xl border border-slate-800 text-center">
            <span className="block text-xl font-black text-orange-500">{accounts.filter(a => a.status === 'pending').length}</span>
            <span className="text-[9px] text-slate-500 font-bold uppercase tracking-widest">Pendentes</span>
          </div>
        </div>
      </div>

      <div className="bg-[#1e293b]/30 border border-slate-800 rounded-3xl overflow-hidden backdrop-blur-md">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-900/40 text-[10px] text-slate-500 uppercase font-black tracking-widest border-b border-slate-800">
              <th className="px-8 py-5">Identificação do Membro</th>
              <th className="px-8 py-5">Status de Acesso</th>
              <th className="px-8 py-5">Registrado em</th>
              <th className="px-8 py-5 text-right">Comandos de Master</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/30">
            {accounts.map(acc => (
              <tr key={acc.id} className="hover:bg-slate-800/20 transition-all duration-300">
                <td className="px-8 py-6">
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm shadow-inner ${
                      acc.role === 'master' ? 'bg-orange-600 text-white' : 'bg-slate-800 text-slate-400'
                    }`}>
                      {acc.username[0].toUpperCase()}
                    </div>
                    <div>
                      <p className="text-sm font-black text-slate-200">{acc.username}</p>
                      <p className="text-[10px] text-slate-500 font-mono tracking-tighter">ID: {acc.id}</p>
                    </div>
                  </div>
                </td>
                <td className="px-8 py-6">
                  <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border shadow-sm ${
                    acc.status === 'approved' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 
                    acc.status === 'pending' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' :
                    'bg-red-500/10 text-red-400 border-red-500/20'
                  }`}>
                    {acc.status === 'approved' ? 'Aprovado' : acc.status === 'pending' ? 'Aguardando' : 'Rejeitado'}
                  </span>
                </td>
                <td className="px-8 py-6 text-xs text-slate-500 font-mono italic">
                  {new Date(acc.joinedAt).toLocaleDateString('pt-BR')}
                </td>
                <td className="px-8 py-6 text-right space-x-2">
                  {acc.role !== 'master' ? (
                    <>
                      {acc.status === 'pending' && (
                        <button 
                          onClick={() => onApprove(acc.id)}
                          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-[10px] font-black uppercase transition-all transform active:scale-95 shadow-lg shadow-emerald-900/20"
                        >
                          Aprovar
                        </button>
                      )}
                      <button 
                        onClick={() => {
                          if(confirm(`Tem certeza que deseja EXCLUIR a conta de ${acc.username}?`)) onDelete(acc.id);
                        }}
                        className="px-4 py-2 bg-slate-800 hover:bg-red-600 text-slate-500 hover:text-white rounded-xl text-[10px] font-black uppercase transition-all shadow-md"
                      >
                        Excluir
                      </button>
                    </>
                  ) : (
                    <span className="text-[10px] text-orange-500/50 font-black uppercase italic tracking-widest mr-4">Dono da Cidade</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {accounts.length === 0 && (
          <div className="p-20 text-center text-slate-600 font-bold uppercase tracking-widest text-xs">Nenhum membro registrado.</div>
        )}
      </div>
    </div>
  );
};

export default AccountManager;
