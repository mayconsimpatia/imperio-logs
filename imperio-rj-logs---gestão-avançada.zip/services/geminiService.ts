
import { GoogleGenAI } from "@google/genai";
import { LogEntry } from "../types";

export async function analyzeLogsForAnomalies(logs: LogEntry[]) {
  try {
    const apiKey = process.env.API_KEY;
    
    // Validação inicial: Verifica se a chave existe
    if (!apiKey || apiKey.trim() === "") {
      return "⚠️ SISTEMA OFFLINE: Chave de API não configurada. Por favor, adicione a API_KEY nas variáveis de ambiente.";
    }

    // Validação de formato: Detecta chaves que parecem ser da Vercel (começam com vck_)
    if (apiKey.includes('vck_')) {
      return "⚠️ CONFIGURAÇÃO INCORRETA: A chave inserida parece ser da Vercel (vck...). É necessária uma chave válida do Google Gemini (aistudio.google.com).";
    }

    // Validação de formato: Aviso sobre chaves que não seguem o padrão Google (AIza...)
    // A chave fornecida pelo usuário (927c...) não parece ser uma chave Gemini padrão.
    if (!apiKey.startsWith('AIza')) {
      console.warn("Aviso: A chave configurada não segue o padrão 'AIza' do Google.");
      // Não retornamos erro imediatamente para permitir testes caso seja um formato novo ou proxy, 
      // mas o aviso abaixo será útil se falhar.
    }

    const ai = new GoogleGenAI({ apiKey: apiKey });
    const recentLogs = logs.slice(0, 15);
    const logSummary = recentLogs.map(l => `[${l.category}] ${l.player.name}: ${l.details}`).join('\n');

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview', 
      contents: `Analise estes logs da cidade IMPERIO RJ e detecte irregularidades como RDM, VDM, Anti-RP ou abuso de staff. Seja breve e direto: \n\n${logSummary}`,
      config: {
        systemInstruction: "Você é o sistema de monitoramento da IMPERIO RJ. Responda em Português. Identifique infratores por Nome e ID. Use emojis táticos.",
        temperature: 0.2,
      }
    });

    return response.text || "Análise concluída: Nenhum padrão anômalo crítico detectado.";
  } catch (error: any) {
    console.error("Erro na IA:", error);
    
    const errString = error.toString();

    // Mensagens de erro claras baseadas na resposta da API
    if (errString.includes('401') || errString.includes('API key')) {
      if (!process.env.API_KEY?.startsWith('AIza')) {
        return "🚫 CHAVE INVÁLIDA: A chave configurada não parece ser uma chave Google Gemini válida (deve começar com 'AIza'). Verifique em aistudio.google.com.";
      }
      return "🚫 ERRO DE AUTENTICAÇÃO: A chave de API fornecida é inválida ou expirou.";
    }

    if (errString.includes('403') || errString.includes('permission')) {
      return "🚫 ACESSO NEGADO: Verifique as permissões da sua chave de API ou se a região é suportada.";
    }

    if (errString.includes('not found') || errString.includes('404')) {
        return "🚫 MODELO INDISPONÍVEL: O modelo 'gemini-3-flash-preview' pode não estar disponível para esta chave ou região.";
    }
    
    return "❌ ERRO NO SISTEMA: Falha ao conectar com o serviço de inteligência. Tente novamente em instantes.";
  }
}
